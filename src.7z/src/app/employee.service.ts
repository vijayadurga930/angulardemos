import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 employees:Employee[]=[
      {eid:111,name:"vijji",salary:36980.55,gender:"female"},
      {eid:222,name:"vijaya",salary:42980.45,gender:"female"},
      {eid:333,name:"durga",salary:45980.65,gender:"female"},
      {eid:444,name:"Tom",salary:33980.78,gender:"male"},
      {eid:555,name:"jerry",salary:38899.85,gender:"male"}
    ];
  
  constructor() { }
  getAllEmployees():Employee[]{
    return this.employees;
  }
  addEmployee(employee:Employee){
    this.employees.push(employee)
    return true;
  }
  deleteEmployee(i:number){
     this.employees.splice(i,1);
  }
}
