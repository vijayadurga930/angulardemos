var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// inheritance
var Employee = /** @class */ (function () {
    function Employee(empId, name) {
        this.empId = empId;
        this.name = name;
    }
    Employee.prototype.display = function () {
        console.log("empId=" + this.empId + "Name=" + this.name);
    };
    return Employee;
}());
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager(empId, name, noOfReporties) {
        var _this = _super.call(this, empId, name) || this;
        _this.display = function () {
            _super.prototype.display.call(_this);
            console.log("NoOfReporties=#" + _this.noOfReporties);
        };
        _this.noOfReporties = noOfReporties;
        return _this;
    }
    return Manager;
}(Employee));
var e = new Employee(143, "vijji");
var m = new Employee(222, "vijaya");
e.display();
m.display();
