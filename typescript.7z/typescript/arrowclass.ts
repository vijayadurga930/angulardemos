//arrow and class definitons

class Customer{
    custId:number;
    name:string;
    constructor(custId:number,name:string){
        this.custId=custId;
        this.name=name;

    }
    show(){
    console.log("custId:"+this.custId+"\nName:"+this.name);
    var customerinfo= 'custId:"${this.custId} "\nName:"+${this.name}';
    console.log(customerinfo);
    }
    display=()=>console.log("custId:"+this.custId+"\nName:"+this.name);
   
} var customer1=new Customer(143,"vijji");
customer1.show();
customer1.display();

