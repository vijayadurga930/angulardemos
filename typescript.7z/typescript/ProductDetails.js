"use strict";
exports.__esModule = true;
var p1 = { productId: 123, name: "mobile", price: 23456 };
var parray = [
    { productId: 124, name: "LG", price: 24345 },
    { productId: 125, name: "MI", price: 24445 },
    { productId: 126, name: "Apple", price: 24545 }
];
parray.push(p1);
for (var _i = 0, parray_1 = parray; _i < parray_1.length; _i++) {
    var p = parray_1[_i];
    console.log("ID=" + p.productId + "\tName=" + p.name + "\tPrice=" + p.price);
}
