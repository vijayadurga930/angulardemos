const colorRed=1;
const colorBlue=2;
enum Colors {Red=1,Blue=2,Green=3};
console.log("red value fro const: "+colorRed);
console.log("Green value fro const: "+Colors.Green);
 let a:number=10;
 var x:number=20;
 function myfunction()
 {
    let b:number=11;
 var y:number=22; 
 }
 if(true)
 {
   let c:number=30;
 var z:number=23;  
 console.log("c="+c); //let block can't access
 console.log("="+c);  //var function u can access
 console.log(a);//b and c block scope
 console.log(x);//y and z function scope
 //invoke yhe function
 myfunction();
 }
