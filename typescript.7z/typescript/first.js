console.log("welcome to typescript");
