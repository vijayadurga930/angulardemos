// Rest params
//function with default value
function fun1(a,b=10){
    return a+b;
}
//rest params
function fun2(...args){
    console.log(args.length);
}
function fun3(name:string,...args){
    console.log("Name:"+name+"\nLength:"+args.length);
}
console.log("Sum="+fun1(3));
fun2();
fun2(5,6);
fun2(9,8,7,6);
fun3("hi");
fun3("hi","hello",4,5);