// Rest params
//function with default value
function fun1(a, b) {
    if (b === void 0) { b = 10; }
    return a + b;
}
//rest params
function fun2() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    console.log(args.length);
}
function fun3(name) {
    var args = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        args[_i - 1] = arguments[_i];
    }
    console.log("Name:" + name + "\nLength:" + args.length);
}
console.log("Sum=" + fun1(3));
fun2();
fun2(5, 6);
fun2(9, 8, 7, 6);
fun3("hi");
fun3("hi", "hello", 4, 5);
