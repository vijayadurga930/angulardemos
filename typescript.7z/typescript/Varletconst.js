var colorRed = 1;
var colorBlue = 2;
var Colors;
(function (Colors) {
    Colors[Colors["Red"] = 1] = "Red";
    Colors[Colors["Blue"] = 2] = "Blue";
    Colors[Colors["Green"] = 3] = "Green";
})(Colors || (Colors = {}));
;
console.log("red value fro const: " + colorRed);
console.log("Green value fro const: " + Colors.Green);
var a = 10;
var x = 20;
function myfunction() {
    var b = 11;
    var y = 22;
}
if (true) {
    var c = 30;
    var z = 23;
    console.log("c=" + c); //let block can't access
    console.log("=" + c); //var function u can access
    console.log(a); //b and c block scope
    console.log(x); //y and z function scope
    //invoke yhe function
    myfunction();
}
