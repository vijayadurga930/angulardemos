import{Product} from "./Product"
let p1:Product={ productId:123,name:"mobile" , price:23456};
let parray:Product[]=[
{productId:124,name:"LG",price:24345},
{productId:125,name:"MI",price:24445},
{productId:126,name:"Apple",price:24545}
];
parray.push(p1);
for(let p of parray){
    console.log("ID="+p.productId+"\tName="+p.name+"\tPrice="+p.price);
}