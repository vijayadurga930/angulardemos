//arrow function
// no parameters and no rturn type
var hi=()=>console.log("welcome to arrow functions");
//with parameter and no return value
var printname=(name)=>console.log("Hello" +name);
//with parameter and with return value
var sum1=(x:number,y:number):number=>{return x+y};
var sum2=(x,y)=>x+y;
var sum3=(x,y)=>x+y;
//calling the arrow function
hi();
printname("vijaya");
console.log("sum1="+sum1(10,20));
console.log("sum2="+sum2(10,30));
console.log("sum3="+sum3(10,10));

