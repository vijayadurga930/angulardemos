export interface Product
{
  productId:number;
  name:string;
  price:number;
}