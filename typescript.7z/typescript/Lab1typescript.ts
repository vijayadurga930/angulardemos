let mobileId:number;
let mobilename:string;
let mobilecost:number;
let Array2:any= [11,"LG",32000];
mobileId=123;
mobilename="Mi"
mobilecost=23456;
console.log(" mobile id:"+mobileId);
console.log(" mobilename:"+mobilename);
console.log(" mobilecost:"+mobilecost);