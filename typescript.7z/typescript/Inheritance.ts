// inheritance
class Employee{
    empId:number;
    name:string;
    constructor(empId:number,name:string){
        this.empId=empId;
        this.name=name;
    }
    display(){
        console.log(`empId=${this.empId}Name=${this.name}`);
}}
class Manager extends Employee{
    noOfReporties:number;
    constructor(empId:number, name:string, noOfReporties:number){
        super(empId,name)
        this.noOfReporties=noOfReporties;
    }
    display=()=>{
        super.display();
        console.log(`NoOfReporties=#${this.noOfReporties}`);
    } }
    var e=new Employee(143,"vijji");
    var m=new Employee(222,"vijaya");
    e.display();
    m.display();
