//arrow and class definitons
var Customer = /** @class */ (function () {
    function Customer(custId, name) {
        var _this = this;
        this.display = function () { return console.log("custId:" + _this.custId + "\nName:" + _this.name); };
        this.custId = custId;
        this.name = name;
    }
    Customer.prototype.show = function () {
        console.log("custId:" + this.custId + "\nName:" + this.name);
        var customerinfo = 'custId:"${this.custId} "\nName:"+${this.name}';
        console.log(customerinfo);
    };
    return Customer;
}());
var customer1 = new Customer(143, "vijji");
customer1.show();
customer1.display();
