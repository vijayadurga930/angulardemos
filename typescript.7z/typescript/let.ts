let empId:number;
let empName:string;
let isstatus:boolean;
let anytype:any;
let myarray:number[]=[10,20,30];
let myarray1:any=[11,'sri',"dhiya",false,45.36];
empId=123;
empName="vijaya";
isstatus=true;
anytype=45.36;
console.log("EID:"+empId);
console.log("Name:"+empName);
console.log("status:"+isstatus);
console.log("Anytype:"+anytype);
console.log(myarray);
console.log()
