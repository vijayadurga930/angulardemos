import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
productData:Product={"id":0,"name":'',"price":0,"brand":''};
  
  constructor(private service:ProductsService,private router:Router) { }

  ngOnInit() {
  }
addproduct()
{
 
this.service.addproduct(this.productData).subscribe((data)=>{this.router.navigate(['customerlist']);});
console.log("added");
}
}
