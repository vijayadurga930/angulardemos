import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Product } from '../product';

@Component({
  selector: 'app-showsearch',
  templateUrl: './showsearch.component.html',
  styleUrls: ['./showsearch.component.css']
})
export class ShowsearchComponent implements OnInit {
searching:Product[];
  constructor(private service:ProductsService) { }

  ngOnInit() {
    console.log(this.service.get);
    this.searching=this.service.get();
    console.log(this.searching);
  }

}
