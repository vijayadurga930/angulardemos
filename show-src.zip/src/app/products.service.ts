import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  url:string="http://localhost:3500/product";
  constructor(private http:HttpClient) { }
  value:Product[];
  filter:Product[];
  getAllProducts(){
    console.log("service")
return this.http.get<Product[]>(this.url);
  }
  deleteproduct(p:Product)
  {
    return this.http.delete<Product[]>(this.url+"/"+p.id);
  }
  addproduct(productData:Product)
  {
    return this.http.post(this.url,productData);
  }
  getsearched(value:Product[])
  {
    this.filter=value;
    console.log(this.value);
    console.log("From getsearched ",this.filter);
  }
  get()
  {
    return this.filter;
  }
}
