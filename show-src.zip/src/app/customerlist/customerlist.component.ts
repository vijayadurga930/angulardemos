import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
product:Product[];
  constructor(private service:ProductsService) { }

  ngOnInit() {
     this.service.getAllProducts().subscribe((data:Product[])=>{this.product=data; console.log(this.product)
    }); 
    
  }
  
  deleteProduct(p:Product)
  {
    this.service.deleteproduct(p).subscribe((data)=>(this.product=this.product.filter(pr=>{pr!==p})));

  }
}
