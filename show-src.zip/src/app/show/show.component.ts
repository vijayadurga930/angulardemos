import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  searchItem:string='';
  product:Product[];
  searching:Product[];
  constructor(private service:ProductsService) { }

  ngOnInit() {
    this.service.getAllProducts().subscribe((data:Product[])=>(this.product=data));
  }
search(value:string)
{
 
  this.searching=this.product.filter((product)=>product.name.toLowerCase().indexOf(value.toLowerCase())!==-1);
  
  this.service.getsearched(this.searching);
}
}
