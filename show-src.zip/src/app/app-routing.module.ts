import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';

import { CustomerlistComponent } from './customerlist/customerlist.component';
import { ShowComponent } from './show/show.component';
import { ShowsearchComponent } from './showsearch/showsearch.component';


const routes: Routes = [
{path:'Home', redirectTo:'customerlist',pathMatch:'full'},
{path:'Show',component:ShowComponent},
{path:'customerlist',component:CustomerlistComponent},
{path:'showsearch',component:ShowsearchComponent},
{ path:'Add', component:AddComponent}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
