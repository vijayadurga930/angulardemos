import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Product } from '../product';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
product:Product[];
  constructor(private service:ProductsService) { }

  ngOnInit() {
  }
  getDetails()
  {
    return this.service.getAllProducts().subscribe((data:Product[])=>{this.product=data; console.log(this.product)});
  }

}
